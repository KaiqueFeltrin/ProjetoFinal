const imagem = document.getElementById("imagem");

imagem.addEventListener("click", () => {
  const texto = "3652-7922";
  navigator.clipboard.writeText(texto).then(() => {
    alert("Texto copiado para a área de transferência com sucesso!");
  }, () => {
    alert("Não foi possível copiar o texto para a área de transferência.");
  });
});
